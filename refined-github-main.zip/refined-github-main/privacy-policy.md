# Privacy Policy

No data or personal information is collected by Refined GitHub.

##### Contact

If you have any questions or suggestions regarding this privacy policy, do not hesitate to [contact us](https://sindresorhus.com/contact).
