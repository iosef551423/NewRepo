import SwiftUI

enum Constants {
	static let appStoreIdentifier = "1519867270"
	static let extensionBundleIdentifier = "com.sindresorhus.Refined-GitHub.Extension"
}
