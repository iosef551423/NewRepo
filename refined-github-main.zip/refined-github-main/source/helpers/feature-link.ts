export default function featureLink(id: FeatureID): string {
	return `https://github.com/refined-github/refined-github/blob/main/source/features/${id}.tsx`;
}
