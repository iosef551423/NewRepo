import './emphasize-draft-pr-label.css';

import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url);
