import './scrollable-areas.css';

import features from '../feature-manager.js';

void features.addCssFeature(import.meta.url);
